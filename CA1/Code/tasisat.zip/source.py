# lis = []

words = [item.strip()[0] for item in list(input().split())]
tmp_words = words

xx = -1
for i in range(len(words)):
    if (words == words[::-1]):
        xx = i
        break
    words = words[1:] + words[0:1]
    # print(words)
    
    


kk = -1 
for i in range(len(tmp_words)):
    if (tmp_words == tmp_words[::-1]):
        kk = i
        break
    tmp_words = tmp_words[len(tmp_words)-1:] + tmp_words[:-1]
    # print(tmp_words)
    
    
    
    
if xx == -1 and kk == -1 :
    print(-1)
else:
    
    print(min(kk,xx))

# print(iSpalindrom)





# lis = [1,2,3,6,3,4]
# lis = lis[len(lis)-1:] + lis[:-1]
# print(lis)


