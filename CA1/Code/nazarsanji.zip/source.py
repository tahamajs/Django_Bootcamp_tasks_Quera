from datetime import datetime,timedelta

start_time = datetime.strptime("00:00", "%H:%M")
end_time = datetime.strptime("00:00", "%H:%M")

lis = []
kk = int(input())
for _ in range(kk):
    time = [i.strip() for i in input().split("-")]
    lis.append(time)
    if(_ == 0):
        start_time = datetime.strptime(time[0], "%H:%M")
        end_time = datetime.strptime(time[1], "%H:%M")
    else:
        if start_time < datetime.strptime(time[0], "%H:%M"):
            start_time = datetime.strptime(time[0], "%H:%M")
        if end_time > datetime.strptime(time[1], "%H:%M"):
            end_time = datetime.strptime(time[1], "%H:%M")

if (end_time - start_time).seconds < 7200 or end_time < start_time:
    raise Exception("Can not find a valid time slot!") 
exhour = timedelta(hours=2)
print((start_time).strftime("%H:%M")+" - "+(start_time+exhour).strftime("%H:%M"))

# print("Earliest start time:", start_time.strftime("%H:%M"))
# print("Latest end time:", end_time.strftime("%H:%M"))
# print((end_time - start_time).seconds)