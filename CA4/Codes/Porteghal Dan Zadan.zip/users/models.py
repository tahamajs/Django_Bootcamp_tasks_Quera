from datetime import date
from django_jalali.db import models as jmodels
from django.db import models
from django.contrib.auth.models import AbstractUser
from jdatetime import datetime
class Seller(AbstractUser):
    birth_date = jmodels.jDateField()
    national_code = models.CharField(max_length=10)

    @property
    def age(self):
        current_date = datetime.now()
        age = current_date.year - self.birth_date.year

        return age

    @property
    def is_birthday(self):
        current_date = datetime.now().date()
        return (
            current_date.month == self.birth_date.month
            and current_date.day == self.birth_date.day
        )

class Product(models.Model):
    weight = models.FloatField()
    price = models.FloatField()
    seller = models.ForeignKey(Seller, on_delete=models.CASCADE)

class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    count = models.IntegerField()
    due_date = jmodels.jDateField()
    created_at = jmodels.jDateTimeField(auto_now_add=True)
