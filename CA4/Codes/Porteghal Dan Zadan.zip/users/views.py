from django.shortcuts import render


def home_page(request):
    ...
    
def good_price_sellers(request):
    ...
    
def expensive_sellers(request):
    ...
    
def seller_orders_count(request, seller_id):
    ...