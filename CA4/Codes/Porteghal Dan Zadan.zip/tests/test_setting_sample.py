from django.test import TestCase
from django.conf import settings


class TestSettings(TestCase):

    def test_timezone(self):
        self.assertEqual(settings.TIME_ZONE, 'Asia/Tehran')

    def test_static_url(self):
        self.assertEqual(settings.STATIC_URL, '/orange_static/')
