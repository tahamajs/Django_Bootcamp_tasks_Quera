from django.test import TestCase, Client
from users.models import Seller, Product, Order
from django.urls import reverse

class ViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Create test data
        self.seller = Seller.objects.create(username='karim', password='testpassword', birth_date='1990-01-01')
        self.seller2 = Seller.objects.create(username='kazem', password='testpassword', birth_date='1999-01-01')
        self.seller3 = Seller.objects.create(username='mazda', password='testpassword', birth_date='1999-01-01')
        self.product1 = Product.objects.create(weight=5.0, price=5000.0, seller=self.seller)
        self.product2 = Product.objects.create(weight=7.0, price=3000.0, seller=self.seller2)
        self.product3 = Product.objects.create(weight=10.0, price=19500.0, seller=self.seller)
        self.order1 = Order.objects.create(product=self.product1, count=3, due_date='2023-08-05')
        self.order2 = Order.objects.create(product=self.product2, count=2, due_date='2023-09-01')
        self.order3 = Order.objects.create(product=self.product1, count=2, due_date='2023-08-05')

    def test_home_page(self):
        response = self.client.get(reverse('home_page'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'فروشنده مشغول فروش پرتقال')
        self.assertContains(response, '1')  # Assuming there's only one seller in the test data