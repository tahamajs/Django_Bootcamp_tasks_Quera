from django.db.models import Count, Avg, Max, ExpressionWrapper, F , fields

from users.models import Seller , Product , Order
from django.db.models import Count , Avg , Sum , Q
from jdatetime import datetime , timedelta


def get_sellers_with_more_than_one_product():
    return Seller.objects.annotate(products_count = Count('product')).filter(products_count__gt = 1)


def get_mean_weight_of_seller_products(seller):
    return Product.objects.filter(seller = seller).aggregate(Avg('weight'))['weight__avg']

def get_sellers_with_more_than_two_products_or_age_greater_than_30():
    # return Seller.objects.annotate(num_products=Count('product')).filter(Q(num_products__gt=2) | Q(age__gt=30))
    return Seller.objects.annotate(num_products=Count('product')).filter(Q(num_products__gt=2) | Q(age__gt=30)).distinct()

def get_sellers_with_good_price():
    thirty_days_ago = datetime.now() - timedelta(days=30)

    good_price_expression = ExpressionWrapper(
        F('price') / F('product__weight'),
        output_field=fields.FloatField()
    )

    return Seller.objects.filter(
        Q(product__order__created_at__gte=thirty_days_ago) | Q(order__created_at__gte=thirty_days_ago),
        good_price_expression__lt=10000
    )

def get_seller_with_max_price():
    return Product.objects.get(price = Product.objects.all().aggregate(Max('price'))['price__max']).seller


def sum_of_orders_in_30_days(seller):
    thirty_days_ago = datetime.now() - timedelta(days=30)
    return Order.objects.filter(product__seller=seller, created_at__gte=thirty_days_ago).aggregate(total_orders=Sum('count'))['total_orders'] or 0
