from django.db.models import Count, Avg, Max

from users.models import Seller , Product , Order
from django.db.models import Count , Avg , Sum , Q
from jdatetime import datetime , timedelta


def get_sellers_with_more_than_one_product():
    return Seller.objects.annotate(products_count = Count('product')).filter(products_count__gt = 1)


def get_mean_weight_of_seller_products(seller):
    return Product.objects.filter(seller = seller).aggregate(Avg('weight'))['weight__avg']

def get_sellers_with_more_than_two_products_or_age_greater_than_30():
    return Seller.objects.filter(
        Q(product__count__gt=2) | Q(age__gt=30)
    )
    # return Seller.objects.annotate(Count('product')).filter(Q(product__count__gt=2) | Q(age__gt=30))



def get_sellers_with_good_price():
    return Seller.objects.annotate(product_count = Count('product')).filter(product_count__gt = 0).annotate(mean_price = Avg('products__price')).filter(mean_price__gt = 100000)
    ##

def get_seller_with_max_price():
    return Product.objects.get(price = Product.objects.all().aggregate(Max('price'))['price__max']).seller


def sum_of_orders_in_30_days(seller):
    thirty_days_ago = datetime.now() - timedelta(days=30)
    return Order.objects.filter(product__seller=seller, created_at__gte=thirty_days_ago).aggregate(total_orders=Sum('count'))['total_orders'] or 0
