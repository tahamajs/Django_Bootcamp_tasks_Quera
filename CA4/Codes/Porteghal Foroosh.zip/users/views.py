from django.shortcuts import render
from django.http import HttpRequest
from .queryset import get_sellers_with_more_than_one_product , get_sellers_with_good_price , get_seller_with_max_price ,sum_of_orders_in_30_days
from .models import Seller
def home_page(request):
    ss = get_sellers_with_more_than_one_product()
    return render(request, 'home_page.html', {'sellers_count': len(ss)})
def good_price_sellers(request):
    ss = get_sellers_with_good_price()
    return render(request, 'good_price_sellers.html', {'sellers': ss})

def expensive_sellers(request):
    ss = get_seller_with_max_price()
    return render(request, 'expensive_sellers.html', {'sellers': ss})
    
def seller_orders_count(request, seller_id):
    ss = sum_of_orders_in_30_days(seller_id)
    if ss :
        return render(request , 'seller_orders_count.html' , {'sales_count' : ss , 'seller_name' : seller_id })
    else :
        return HttpRequest('هیچ')