from datetime import date
from django_jalali.db import models as jmodels
from django.db import models
from django.contrib.auth.models import AbstractUser, Permission, Group
from jdatetime import datetime

class Seller(AbstractUser):
    birth_date = jmodels.jDateField()
    national_code = models.CharField(max_length=10)

    # Provide custom related names for groups and user_permissions
    groups = models.ManyToManyField(Group, verbose_name='groups', blank=True, related_name='sellers')
    user_permissions = models.ManyToManyField(Permission, verbose_name='user permissions', blank=True, related_name='sellers')
    @property
    def age(self):
        current_date = datetime.now()
        age = current_date.year - self.birth_date.year
        return age

    @property
    def is_birthday(self):
        current_date = datetime.now().date()
        return (
            current_date.month == self.birth_date.month
            and current_date.day == self.birth_date.day
        )

class Product(models.Model):
    weight = models.FloatField(default=0)
    price = models.FloatField(default=0)
    seller = models.ForeignKey(Seller, on_delete=models.CASCADE)

class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    count = models.IntegerField(default=0)
    due_date = jmodels.jDateField(null=True)
    created_at = jmodels.jDateTimeField(auto_now_add=True)
