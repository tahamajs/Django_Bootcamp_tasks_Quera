from django.core.exceptions import ValidationError
import re

class CustomPasswordValidator:
    def __init__(self):
        self.regex_pattern = r"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&])[A-Za-z\d!@#$%^&]{8,}$"

    def validate(self, password, user=None):
        if not re.match(self.regex_pattern, password):
            raise ValidationError("password is not valid")
