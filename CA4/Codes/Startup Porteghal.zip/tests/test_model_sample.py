from django.test import TestCase
from django.contrib.auth import get_user_model
from datetime import date
import jdatetime

Seller = get_user_model()

class ModelTests(TestCase):
    def setUp(self):
        # Create a test seller
        self.seller = Seller.objects.create(username='testuser', password='testpassword', birth_date=jdatetime.date(1378, 1, 25))
        self.seller2 = Seller.objects.create(username='testuser2', password='testpassword', birth_date=jdatetime.date.today())

    def test_seller_age(self):
        self.seller.birth_date = date(1378, 9, 22)
        self.assertEqual(self.seller.age, 24)
