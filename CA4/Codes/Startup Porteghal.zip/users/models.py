from django.db import models


class Seller:
    ...


class Product(models.Model):
    ...

class Order(models.Model):
    ...
