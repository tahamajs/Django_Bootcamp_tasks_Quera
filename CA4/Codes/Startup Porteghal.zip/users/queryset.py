from users.models import Seller


def get_sellers_with_more_than_one_product():
    pass


def get_mean_weight_of_seller_products(seller):
    pass


def get_sellers_with_more_than_two_products_or_age_greater_than_30():
    pass


def get_sellers_with_good_price():
    pass


def get_seller_with_max_price():
    pass


def sum_of_orders_in_30_days(seller):
    pass
