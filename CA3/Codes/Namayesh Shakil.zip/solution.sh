awk -F'|' 'BEGIN {OFS=" - "}    NR==1 {print "col1", "col2", "col3"} NR>=1 {print $1, $2, $3 ;sum+=$3} END {print sum}' data.txt
