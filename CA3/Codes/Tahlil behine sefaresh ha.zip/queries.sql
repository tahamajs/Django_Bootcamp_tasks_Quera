-- Section1
CREATE INDEX idx_created_at ON orders(created_at,total);
-- Section2
CREATE INDEX idx_user_id_created_at ON orders (user_id, created_at,total);

-- Section3
