-- Section1
select customers.name ,customers. phone
from orders
join customers on  customers.id = orders.customer_id
group by customers.name , customers.phone
order by count(orders.customer_id) desc
limit 1;

-- Section2
select foods.id , foods.name
from orders
INNER JOIN restaurant_foods on restaurant_foods.id = orders.restaurant_food_id
INNER JOIN foods on foods.id = restaurant_foods.food_id
group by food_id
order by avg(rate) desc , foods.id
limit 10;

-- Section3
select restaurants.id , restaurants.name
from orders
INNER JOIN restaurant_foods on restaurant_foods.id = orders.restaurant_food_id
INNER JOIN restaurants on restaurants.id = restaurant_foods.restaurant_id
group by restaurants.id
order by AVG(rate) desc , restaurants.id
limit 10;
-- Section4
    your 4th query here